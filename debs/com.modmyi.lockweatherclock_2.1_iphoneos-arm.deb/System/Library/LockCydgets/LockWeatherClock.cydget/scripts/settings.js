﻿var settingsObject = {};

settingsObject["languages"] = "en"; 
settingsObject["celsius"] = false; 
settingsObject["twentyfour"] = false;
settingsObject["refresh"] = 15;
settingsObject["padzero"] = false;
settingsObject["color"] = "white";
settingsObject["bgcolor"] = "transparent";
settingsObject["custom"] = false;




