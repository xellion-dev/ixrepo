﻿(function () {
    "use strict";
    var weekdays, months, currentTime, currentHours, currentMinutes, day, month, date;
    var TwentyFourHour = settingsObject.twentyfour;
    var PadZero = settingsObject.padzero;
    var language = settingsObject.languages;

    if (language == "en") {
        weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    }
    else if (language == "no") {
        weekdays = ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"];
        months = ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"];
    }
    else if (language == "nl") {
        weekdays = ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"];
        months = ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"];
    }
    else if (language == "fi") {
        weekdays = ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"];
        months = ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kesäkuu", "Heinäkuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"];
    }
    else if (language == "it") {
        weekdays = ["Domenica", "Lunedi", "Martedì", "Mercoledì", "Giovedi", "Venerdì", "Sabato"];
        months = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
    }
    else if (language == "ru") {
        weekdays = ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"];
        months = ['Января', 'Февраля', 'Марта', 'Апреля', 'Мая', 'Июня', 'Июля', 'Августа', 'Сентября', 'Октября', 'Ноября', 'Декабря'];
    }
    else if (language == "sp") {
        weekdays = ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"];
        months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    }
    else if (language == "cn") {
        weekdays = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
        months = ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'];
    }
    else if (language == "fr") {
        weekdays = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
        months = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre", "Octobre", "Novembre", "Decembre"];
    }
    else if (language == "ge") {
        weekdays = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
        months = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
    }
    else if (language == "ro") {
        weekdays = ["Luni", "Marti", "Miercuri", "Joi", "Vineri", "Sâmbata", "Duminica"];
        months = ["Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"];
    }
    else if (language == "cz") {
        weekdays = ["Neděle", "Pondělí", "Úterý", "Středa", "Čtvrtek", "Pátek", "Sobota"];
        months = ["Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec"];
    }
    else {
        weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    }

    currentTime = new Date();
    currentMinutes = currentTime.getMinutes();
    currentMinutes = (currentMinutes < 10) ? '0' + currentMinutes : currentMinutes;
    currentHours = currentTime.getHours();

    if (!TwentyFourHour) { currentHours = ((currentHours + 11) % 12 + 1); }
    if (PadZero) {
        if (currentHours <= 9) {
            currentHours = '0' + currentHours;
        }
    }

    day = currentTime.getDay();
    month = currentTime.getMonth();
    date = currentTime.getDate();
    document.getElementById('clock').innerHTML = currentHours + ':' + currentMinutes;
    if (language == "en")
        document.getElementById('date').innerHTML = weekdays[day] + ', ' + months[month] + ' ' + date;
    else
        document.getElementById('date').innerHTML = weekdays[day] + ', ' + date + '. ' + months[month];
} ());