#!/bin/bash
# cds.sh - improved cd command
# written by Ad@m <http://adam.hbang.ws>
# licensed under the MIT License <http://adam.mit-license.org>
# setup: save as /etc/profile.d/cds.sh and restart your shell
# usage: cd to a directory as usual, then “cd -” to go back to
#        the previous directory, even if you restart your shell
# changelog: 1.1 - relative paths now supported
#            1.0 - initial release
cd () {
    if [[ $1 == "-" && ! -f "$PWD/-" && -f ~/.lastdir ]]; then
        builtin cd "$(cat ~/.lastdir)"
    elif [[ $1 == "-" && ! -f ~/.lastdir ]]; then
        pwd>~/.lastdir
    else
        builtin cd $*
        pwd>~/.lastdir
    fi
}
cd ->/dev/null