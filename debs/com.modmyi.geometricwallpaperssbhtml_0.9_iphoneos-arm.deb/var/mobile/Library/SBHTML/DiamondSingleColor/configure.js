// ----------------------------- //
// Geometric lockscreens config
// ----------------------------- //
// Need to be applied for each theme (so in the configure.js file in each folder)
// You can however copy the .js and overwrite the others.

// Remove any colors you don't want used from the variable below.
var color = ["oranges","moreorange","darkorange","champagne","pink","blues","midblues","darkblues","moreblue","mellowyellow","yellow","silver","greys","lightgreys","lightred","darkred","pink","deeppurple","purple","morepurple","teal","greens","darkgreen","mintgreen","lightgreen","brown","lightbrown"];

// ----------------------------- //
// Single color option
// ----------------------------- //
// If you want a single color, pick one from the var above.
// Uncomment, the line below, remove //
// Fill in a color into the quotes (= [".."]) below.
//var color = ["pickacolor"];

// ------------------------------------------------------------------------- //
// The follow only applies for the RandomGeometryThemeWithSingleColor theme.
// ------------------------------------------------------------------------- //
var themes = ["Diamond","Geometry","Hexagon","Polygon","SquaresRotated","Squares","Triangles"];
// If you remove names from the above var and later want to put some back, 
// use the theme name but leave out the 'SingleColor' bit.