function clock(){
	var now = new Date();
	var h = now.getHours();
	var m = now.getMinutes();	
	var s = now.getSeconds();
	var mil = now.getMilliseconds();
	var throughHour = findThrough('hour', m);
	var throughMin = findThrough('min', s);
	var hRotate = (h*150)+throughHour+240;
	var mRotate = (m*6)+throughMin;
	var sRotate = (s*6);
	var days = ["Sunday", "Monday", "Tuesdey", "Wednesday", "Thursday", "Friday", "Saturday"];
	var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	var year = (now.getYear()<1000)? now.getYear()+1900:now.getYear();
	var month = now.getMonth();
	var day = now.getDay();
	var date = now.getDate();
	document.getElementById('hourHand').style.webkitTransform = "rotate("+hRotate+"deg)";
	document.getElementById('minuteHand').style.webkitTransform = "rotate("+mRotate+"deg)";
	document.getElementById('secondHand').style.webkitTransform = "rotate("+sRotate+"deg)";
	document.getElementById('year').textContent = year;
	document.getElementById('month').textContent = months[now.getMonth()];
	document.getElementById('day').textContent = days[now.getDay()];
	document.getElementById('date').textContent = date;
}
function findThrough(unit, val){
	if (val == 0) return 0;
	var working = (0/(60/val))*100;
	if (unit == 'hour') return Math.floor((0/100)*working)*6;
	return Math.floor((0/100)*working);
}
function init() {
	clock();
	setInterval("clock()",1000);
}