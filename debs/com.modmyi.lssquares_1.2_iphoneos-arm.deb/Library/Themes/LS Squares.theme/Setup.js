/************* LS Squares Setup *************/


/********** Configure location here **********
Because of limitations provided by the weather lookup using weather code (e.g. "USCA0638", "FRXX0076"), I had to change it to WOEID lookup instead.
To get your WOEID:
1. Visit http://woeid.rosselliot.co.nz/
2. Enter your city, address or zip code
3. Copy your corresponding WOIED (all numeric) from the search results. If there are no search results, try searching again but use a different input (e.g. zip code instead of city, or complete city name, etc)
4. Enter the code below (retain the quotation marks and the semi-colon)

Examples:
var locale = "44418" - London
var locale = "615702" - Paris
var locale = "721943" - Rome
var locale = "638242" - Berlin
var locale = "2442047"- Los Angeles
var locale = "1199477" - Manila
var locale = "2122265" - Moscow
*********************************************/
var locale = "2442047";


/***** Reading based on current location *****
With the fear of accidentally turning on GPS based readings and draining battery life, I placed this option at the bottom of this file.
*********************************************/


/*********** Set time format here ************
Toggle between twelve and twenty-four hour format
> false = 12h time format
> true = 24h time format
*********************************************/
var twentyFourHourTime = false;


/************** Weather options **************
> Celsius = C
> Fahrenheit = F

Real Feel takes into account wind chill, speed and humidity. It's not perfect, but it's a lot closer than it used to be.

updateInterval is how often the function would update the weather. Low number means more accurate current weather/temperature reading, but affects battery life more. High number is vice-versa.
> updateInterval is interpreted in minutes, and minutes only. 
*********************************************/
var tempType = "F";
var useRealFeel = true;
var updateInterval = 30;


/************** Choose language **************
Choose language:
> English = EN
> French = FR
> Spanish = SP
> German = DE
> Italian = IT
> Dutch = NL
> Filipino = PH
> Danish = DA
*********************************************/
var language = "EN";


/************* Set position here *************
Move the location of the objects (as one). Entries can be in "px" or "%". Keep value in-between quotes;
Example:
> "30%";
> "150px";
Remember, the two positions here refer to the starting point of the lockscreen theme elements (top-left point).
*********************************************/
var upDownPosition = "8%";
var leftRightPosition = "0%";


/***** Reading based on current location *****
Warning: This could affect your battery life. I've read from a post from the creator of the tweak that it shouldn't affect it at all, but a part of me says it would. Use at your own discretion.

Anyway, to make this feature work, please install "MyLocation" tweak from "http://www.myrepospace.com/profile/kohidevice" repo, if you don't have it already. Open the app first and allow it to use "Location Services". Then turn "Sig. Change" to "On". After that, go into the Settings app -> Privacy -> Location Services. The MyLocation app should show up here and be turned on for you to get updates while traveling. You should then find a "myLocation.txt" inside the Documents folder containing your current longitude and latitude. This file would get constantly updated by the "MyLocation" tweak. 

(complete my installation instructions found in "readmeMyLocation.txt" inside the Resources folder)

gpsBasedReading is by default set to "false". Set to "true" if you want to use this feature. Just a note, if somehow the coordinates weren't correctly identified, the theme is going to show its reading based off the location set in the variable "locale" in Setup.js. This is done to prevent showing empty data.

gpsCheckRefreshTimer is the interval (in minutes) on how often the the theme checks your current location.
> gpsCheckRefreshTimer is interpreted in minutes, and minutes only. 
*********************************************/
var gpsBasedReading = false;
var gpsCheckRefreshTimer = 30;