/***** LS Squares TRANSLATION functions *****/


function getDayName(day)
{
	var daysArray;
	
	switch (language)				/* 1 */
	{
		case "FR":	daysArray = new Array("dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi");
					break;
		case "SP":	daysArray = new Array("domingo", "lunes", "martes", "mi�rcoles", "jueves", "viernes", "s�bado");
					break;
		case "DE":	daysArray = new Array("sonntag", "montag", "dienstag", "mittwoch", "donnerstag", "freitag", "samstag");
					break;
		case "IT":	daysArray = new Array("domenica", "lunedi", "marted�", "mercoledi", "giovedi", "venerd�", "sabato");
					break;			
		case "NL":	daysArray = new Array("zondag", "maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag");
					break;
		case "PH":	daysArray = new Array("linggo", "lunes", "martes", "miyerkules", "huwebes", "biyernes", "sabado");
					break;
		case "DA":	daysArray = new Array("s�ndag", "mandag", "tirsdag", "onsdag", "torsdag", "fredag", "l�rdag");
					break;
		default:	daysArray = new Array("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday");		/* 2 */
	}

    return daysArray[day];
}


function getMonthName(month)
{
	var monthsArray;
	
	switch (language)				/* 1 */
	{
		case "FR":	monthsArray = new Array("jan", "f�v", "mar", "avr", "mai", "jun", "jul", "ao�", "sep", "oct", "nov", "d�c");
					break;
		case "SP":	monthsArray = new Array("ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic");
					break;
		case "DE":	monthsArray = new Array("jan", "feb", "m�r", "apr", "mai", "jun", "jul", "aug", "sep", "okt", "nov", "dez");
					break;
		case "IT":	monthsArray = new Array("gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic");
					break;											          
		case "NL":	monthsArray = new Array("jan", "feb", "maa", "apr", "mei", "jun", "jul", "aug", "sep", "okt", "nov", "dec");
					break;
		case "PH":	monthsArray = new Array("ene", "peb", "mar", "abr", "may", "hun", "hul", "ago", "set", "okt", "nob", "dis");
					break;
		case "DA":	monthsArray = new Array("jan", "feb", "mar", "apr", "maj", "jun", "jul", "aug", "sep", "okt", "nov", "dec");
					break;
		default:	monthsArray = new Array("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec");		/* 2 */
	}
	
	return monthsArray[month];
}


function getWeatherText(weatherCode)
{
	var weatherTextArray;
	
	switch (language)
	{
		case "FR":	weatherTextArray = new Array("tornade", "temp�te tropicale", "ouragan", "des orages violents", "orages", "neige et pluie mixte", "neige et pluie mixte", "verglas et neige mixte", "bruine vergla�ante", "bruine", "pluie vergla�ante", "douches", "douches", "averses de neige", "averses de neige l�g�re", "poudrerie", "neige", "je vous salue", "gr�sil", "poussi�re", "brumeux", "brume", "fum�", "venteux", "venteux", "froid", "nuageux", "principalement nuageux", "principalement nuageux", "partiellement nuageuse", "partiellement nuageux", "d�gag�", "ensoleill�", "foire/salon", "foire/salon", "gr�le et pluie mixte", "chaud", "orages isol�s", "orages �parses", "orages �parses", "averses �parses", "fortes chutes de neige", "averses de neige �parses", "fortes chutes de neige", "partiellement nuageux", "orages", "averses de neige", "orages isol�s");
					break;
		case "SP": weatherTextArray = new Array("tornado", "tormenta tropical", "hurac�n", "tormentas severas", "tempestades de truenos", "nieve y la lluvia mezclada", "aguanieve y lluvia mezclada", "aguanieve y nieve mezclada", "engelante llovizna", "llovizna", "lluvia helada", "duchas", "duchas", "r�fagas de la nieve", "duchas de nieve ligera", "ventisca", "nieve", "granizo", "aguanieve", "polvo", "niebla", "neblina", "ahumado", "poco ventoso", "ventoso", "fr�o", "nublado", "mayormente nublada", "mayormente nublado", "parcialmente nublada", "parcialmente nublado", "claro", "soleado", "feria", "Feria", "granizo y lluvia mezclada", "caliente", "tormentas aisladas", "tormentas dispersas", "tormentas dispersas", "lloviznas", "nevadas", "duchas de nieve dispersos", "nevadas", "parcialmente nublado", "tormentosos", "duchas de nieve", "tormentas aisladas");		
					break;
		case "DE":	weatherTextArray = new Array("tornado", "tropischer sturm", "hurrikan", "schweren gewittern", "gewitter", "gemischte regen und schnee", "gemischte Regen und graupel", "gemischte schnee und graupel", "einfrieren nieselregen", "nieselregen", "glatteisregen", "duschen", "duschen", "schnee-schneegest�ber", "leichte schneeschauer", "weht schnee", "schnee", "hagel", "graupel", "staub", "neblig", "dunst", "rauchig", "st�rmischen", "windig", "kalt", "bew�lkt", "meistens bew�lkt", "meistens bew�lkt", "�berwiegend bew�lkt", "stark bew�lkt", "deaktivieren", "sonnig", "messe", "messe", "gemischte regen und hagel", "hei�", "isolierte gewitter", "vereinzelte gewitter", "vereinzelte gewitter", "vereinzelte schauer", "schneedruck", "vereinzelte schneeschauer", "schneedruck", "�berwiegend bew�lkt", "gewitterregen", "schneeschauer", "isolierten gewitterregen");
					break;
		case "IT":	weatherTextArray = new Array("tornado", "tempesta tropicale", "uragano", "violenti temporali", "temporali", "neve e pioggia mista", "nevischio e pioggia mista", "nevischio e neve mista", "pioviggine congelantesi", "pioggerella", "pioggia gelida", "docce", "docce", "folate di neve", "neve leggera docce", "che soffia neve", "neve", "grandine", "nevischio", "polvere", "nebbioso", "foschia", "fumoso", "un fortissimo", "ventoso", "freddo", "nuvoloso", "per lo pi� nuvolosa", "per lo pi� nuvoloso", "parzialmente nuvolosa", "parzialmente nuvoloso", "chiaro", "soleggiato", "fiera", "fiera", "grandine e pioggia mista", "caldo", "isolati temporali", "temporali sparsi", "temporali sparsi", "acquazzoni sparsi", "neve pesante", "docce di neve sparsi", "neve pesante", "parzialmente nuvoloso", "soleggiato", "neve docce", "rovesci isolati");
					break;
		case "NL":	weatherTextArray = new Array("tornado", "tropische storm", "orkaan", "zware onweersbuien", "onweersbuien", "gemengde regen en sneeuw", "gemengde regen en natte sneeuw", "gemengde sneeuw en ijzel", "bevriezing motregen", "motregen", "aanvriezende regen", "douches", "douches", "sneeuwvlagen", "lichte sneeuwbuien", "blazen sneeuw", "sneeuw", "hagel", "ijzel", "stof", "mistig", "waas", "rokerig", "heftig", "winderig", "koude", "bewolkt", "wisselend bewolkt", "wisselend bewolkt", "gedeeltelijk bewolkt", "gedeeltelijk bewolkt", "helder", "zonnig", "mooi", "mooi", "gemengde regen en hagel", "heet", "ge�soleerde onweersbuien", "verspreide onweersbuien", "verspreide onweersbuien", "verspreide buien", "zware sneeuw", "verspreid sneeuwbuien", "zware sneeuw", "gedeeltelijk bewolkt", "onweersbuien", "sneeuwbuien", "ge�soleerde onweersbuien");
					break;
		case "PH": weatherTextArray = new Array("buhawi", "tropikal na bagyo", "bagyo", "matinding bagyo", "bagyo", "halo-halong pag-ulan at niyebe", "halo-halong pag-ulan na may kasamang niyebe", "halo-halong niyebe at pag-ulan", "nagyeyelong ambon", "ambon", "nagyeyelong ulan", "maulan", "maulan", "matinding niyebe", "kaunting pag-niyebe", "mahanging pag-niyebe", "niyebe", "ulang may yelo", "ulan kasama ng niyebe", "maalikabok", "maulap", "manipis na ulap", "mausok", "bahagyang mahangin", "mahangin", "malamig", "maulap", "maulap-ulap", "maulap-ulap", "bahagyang maulap", "bahagyang maulap", "maaliwalas", "maaraw", "mainam", "mainam", "halo-halong pag-ulan at ulang may niyebe", "mainit", "mailan-ilang pag-bagyo", "makalat na pag-bagyo", "makalat na pag-bagyo", "makalat na pag-ulan", "malakas na pag-niyebe", "makalat na pag-niyebe", "bahagyang maulap", "makulog na pag-ulan", "niyebeng pag-ulan", "mailan-ilang kulog na pag-ulan");	
					break;
		case "DA":	weatherTextArray = new Array("tornado", "tropisk storm", "orkan", "sv�r tordenvejr", "tordenvejr", "blandet regn og sne", "blandet regn og slud", "blandet sne og slud", "frysning st�vregn", "st�vregn", "isslag", "brusere", "brusere", "snefnug", "lette snebyger", "snefygning", "sne", "hagl", "slud", "st�v", "t�get", "diset", "r�get", "bl�sende", "bl�sende", "kolde", "overskyet", "overvejende skyet", "overvejende skyet", "delvist overskyet", "delvist overskyet", "klart", "solrig", "retf�rdig", "retf�rdig", "blandet regn og hagl", "varmt", "lokalt tordenvejr", "spredt tordenvejr", "spredt tordenvejr", "spredte byger", "tunge sne", "spredt snebyger", "tunge sne", "delvist overskyet", "regnbyger og tordner", "snebyger", "olerede regnbyger og tordner");
					break;
		default:	weatherTextArray = new Array("tornado", "tropical storm", "hurricane", "severe thunderstorms", "thunderstorms", "mixed rain and snow", "mixed rain and sleet", "mixed snow and sleet", "freezing drizzle", "drizzle", "freezing rain", "showers", "showers", "snow flurries", "light snow showers", "blowing snow", "snow", "hail", "sleet", "dust", "foggy", "haze", "smoky", "blustery", "windy", "cold", "cloudy", "mostly cloudy", "mostly cloudy", "partly cloudy", "partly cloudy", "clear", "sunny", "fair", "fair", "mixed rain and hail", "hot", "isolated thunderstorms", "scattered thunderstorms", "scattered thunderstorms", "scattered showers", "heavy snow", "scattered snow showers", "heavy snow", "partly cloudy", "thundershowers", "snow showers", "isolated thunderstorms");		/* 2 */
	}	
	
	return weatherTextArray[weatherCode];
}


/************ FOOTNOTES/COMMENTS *************
1. language variable is initialized and declared from Setup.js
2. default to English
*********************************************/