/******* LS Squares WEATHER functions *******/


var postal;

function getWeatherTemp()
{
	if (gpsBasedReading == false)
	{
		validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal);
		setInterval("fetchWeatherData(dealWithWeather, postal)", 1000*60*updateInterval);		/* 1 */
	}
	else
	{
		updateCurrentLocation();
		setInterval("updateCurrentLocation()", 1000*60*gpsCheckRefreshTimer);					/* 1 */	
	}
}


function setPostal(obj)
{
	if (obj.error == false)
		if (obj.cities.length > 0)
		{
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%");
			fetchWeatherData(dealWithWeather, postal);
		}
		else
			document.getElementById("weatherSquare").innerHTML = "<img src='Images/WeatherIcons/NA.png'><p id='weatherText'>not found</p>";
	else
		document.getElementById("weatherSquare").innerHTML = "<img src='Images/WeatherIcons/NA.png'><p id='weatherText'>" + obj.errorString + "</p>";
}


function fetchWeatherData(callback, woeid)
{
	var tempUnit;
	
	if (tempType == "C" || tempType == "c")			/* 2 */
		tempUnit = 'c';
	else
		tempUnit = 'f';
	
	var url = "http://weather.yahooapis.com/forecastrss?w=";
	var xml_request = new XMLHttpRequest();
	xml_request.onload = function(e) {xmlLoaded(e, xml_request, callback);}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url + woeid + "&u=" + tempUnit);
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);
	
	return xml_request;
}


function xmlLoaded(event, request, callback)
{
	if (request.responseXML)
	{
		var obj = {error:false, errorString:null};
		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
		obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city");
		obj.windChill = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
		obj.windSpeed = findChild(effectiveRoot, "yweather:wind").getAttribute("speed");
		obj.humidity = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("humidity");
		obj.speedUnit = findChild(effectiveRoot, "yweather:units").getAttribute("speed");
	
		var conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
		obj.temp = conditionTag.getAttribute("temp");
		obj.icon = conditionTag.getAttribute("code");
		obj.description = conditionTag.getAttribute("text");

		var forecast = findChild(findChild(effectiveRoot, "item"), "yweather:forecast");
		obj.todaylow = forecast.getAttribute("low");
		obj.todayhigh = forecast.getAttribute("high");
		
		if (obj.description == "Unknown")
		{
			obj.icon = forecast.getAttribute("code");
			obj.description = forecast.getAttribute("text");
		}

		if (obj.icon == 3200) 
			obj.icon = 48;
	
		callback (obj); 
	}
	else
		callback ({error:true, errorString:"XML request failed. no responseXML"});
}


function findChild(element, nodeName)
{
	var child;
	
	for (child = element.firstChild; child != null; child = child.nextSibling)
		if (child.nodeName == nodeName)
			return child;
	
	return null;
}


function dealWithWeather(obj)
{
	var weatherImgSrc = "";
	var weatherText = "";
	var temperatureText = "";
	
	if (obj.error == false)
	{
		//weather
		weatherImgSrc = "Images/WeatherIcons/" + obj.icon + ".png";
		weatherText = getWeatherText(obj.icon);		/* 4 */
	
		if (weatherText.length > 25)
			document.getElementById("weatherSquare").style.fontSize = "1.0em";
		else if (weatherText.length < 15)
			document.getElementById("weatherSquare").style.fontSize = "1.15em";
		else
			document.getElementById("weatherSquare").style.fontSize = "1.1em";

		document.getElementById("weatherSquare").innerHTML = "<img src='" + weatherImgSrc + "'><p id='weatherText'>" + weatherText + "</p>";
		
		//temperature
		var temporaryTempVal;
		
		if (useRealFeel == true)					/* 3 */
			temporaryTempVal = calculateRealFeel(obj)			
		else
			temporaryTempVal = obj.temp;
			
		if (tempType == "C" || tempType == "c")    /* 2 */
			temperatureText = "<p id='temperatureText'>" + temporaryTempVal+ "&#176;C" + "</p>";
		else
	       temperatureText = "<p id='temperatureText'>" + temporaryTempVal+ "&#176;F" + "</p>";

		var tempLowHighText;
		tempLowHighText = "<p id='tempLowHighText'>L: " + obj.todaylow + "&#176;" + " | H: " + obj.todayhigh + "&#176;";
		
		document.getElementById("temperatureSquare").innerHTML = temperatureText + tempLowHighText;
	}
}


function constructError(string)
{
	return {error:true, errorString:string};
}


function validateWeatherLocation(location, callback)
{
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location}; 
	callback (obj);
}


function calculateRealFeel(obj)
{
	var realFeel;
	
	var fahrenheitValue;
	var windChillValue;
	var humidityValue;
	var windSpeedValue;

	//convert to F first
	if (tempType == "C" || tempType == "c")
		fahrenheitValue = convertToF(obj.temp);
	else
		fahrenheitValue = obj.temp;

	//convert to miles
	if (obj.speedUnit == "km/h")
		windSpeedValue = convertToM(obj.windSpeed);
	else
		windSpeedValue = obj.windSpeed;

	humidityValue = obj.humidity;

	//check if heat index (and humidity) or wind chill (and air speed)
	if (fahrenheitValue > 73 && humidityValue >= 40)
	{
		realFeel = getHeatIndex(fahrenheitValue, humidityValue);

		//if originally in C, convert back
		if (tempType == "C" || tempType == "c")
			realFeel = convertToC(realFeel);
	}
	else if (fahrenheitValue < 50 && windSpeedValue >= 3)
		realFeel = obj.windChill;
	else
		realFeel = obj.temp;
				
	return Math.round(realFeel);
}


function convertToF(temp)
{
	return (temp * 9/5) + 32;
}


function convertToC(temp)
{
	return (temp - 32) * (5/9);
}


function convertToM(speed)
{
	return speed * 0.6214;
}


function getHeatIndex(temp, humidity)
{
	return -42.379 + 2.04901523*temp + 10.14333127*humidity - 0.22475541*temp*humidity - 6.83783*Math.pow(10,-3)*Math.pow(temp, 2) - 5.481717*Math.pow(10,-2)*Math.pow(humidity, 2) + 1.22874*Math.pow(10,-3)*Math.pow(temp, 2)*humidity + 8.5282*Math.pow(10,-4)*temp*Math.pow(humidity, 2) - 1.99*Math.pow(10,-6)*Math.pow(temp, 2)*Math.pow(humidity, 2);
}


/************ FOOTNOTES/COMMENTS *************
1. updateInterval and gpsCheckRefreshTimer variable is initialized and declared from Setup.js
2. tempType variable is initialized and declared from Setup.js 
3. useRealFeel variable is initialized and declared from Setup.js
4. get weather text in TranslationFunctions.js based on language 
5. http://www.meteor.iastate.edu/~ckarsten/bufkit/apparent_temperature.html
6. http://en.wikipedia.org/wiki/Heat_index
7. http://en.wikipedia.org/wiki/Wind_chill
*********************************************/