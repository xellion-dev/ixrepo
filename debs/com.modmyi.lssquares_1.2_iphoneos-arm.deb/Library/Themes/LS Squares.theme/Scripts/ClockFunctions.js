/******** LS Squares CLOCK functions ********/


function initialize()
{
	//position elements
	document.getElementById("container").style.marginTop = upDownPosition;		/* 1 */
	document.getElementById("container").style.marginLeft = leftRightPosition;	/* 1 */
	
	//initialize elements
	document.getElementById("timeSquare").innerHTML = "";
	document.getElementById("dateDaySquare").innerHTML = "";
	document.getElementById("weatherSquare").innerHTML = "<img src='Images/WeatherIcons/NA.png'><p id='weatherText'>not set</p>";
	document.getElementById("temperatureSquare").innerHTML = "<p id='temperatureText'>!</p><p id='tempLowHighText'>L: ! | H: !";
}


function getTimeDateDay()
{
	var timeDateDay = new Date();
	var time = getCurrTime(timeDateDay);
	var dateDay = getCurrDateDay(timeDateDay);
	
	document.getElementById("timeSquare").innerHTML = time;
	document.getElementById("dateDaySquare").innerHTML = dateDay;
	
	setTimeout("getTimeDateDay()", 1000);
}


function getCurrTime(timeDateDay)
{
	var hours = timeDateDay.getHours();
	var minutes = timeDateDay.getMinutes();
	var seconds = timeDateDay.getSeconds();

	var timeText = "";
	var ampmLocalText = "";

	if (twentyFourHourTime == false)						/* 2 */
	{
		if (hours < 12)
			ampmLocalText = "am";
		else
		{
			ampmLocalText = "pm";
			hours = hours - 12;
		}
		
		if (hours == 0)
			hours = 12;
		
		if (minutes < 10)
			minutes = "0" + minutes;
		
		timeText = "<p id='twelveHourTimeText'>" + hours + ":" + minutes + "</p><p id='ampmText'>" + ampmLocalText + "</p>";
	}
	else
	{
		if (hours == 0)
			hours = "0" + hours;
			
		if (minutes < 10)
			minutes = "0" + minutes;
		
		timeText = "<p id='twentyFourHourTimeText'>" + hours + ":" + minutes + "</p>";
	}
		ampmLocalText = "";

	return timeText;
}


function getCurrDateDay(timeDateDay)
{
	var dateText = getCurrDate(timeDateDay);
	var dayText = getCurrDay(timeDateDay);

	return "<p id='dateText'>" + dateText + "</p><p id='dayText'>" + dayText + "</p>";
}


function getCurrDate(timeDateDay)
{
	var month = timeDateDay.getMonth();
	var date = timeDateDay.getDate();

	return getMonthName(month) + date;				/* 3 */
}


function getCurrDay(timeDateDay)
{
	var day = timeDateDay.getDay();

	return getDayName(day);							/* 3 */
}


/************ FOOTNOTES/COMMENTS *************
1. upDownPosition and leftRightPosition variables are initialized and declared from Setup.js
2. twentyFourHourTime variable is initialized and declared from Setup.js
3. get month and day name in TranslationFunctions.js based on language
*********************************************/