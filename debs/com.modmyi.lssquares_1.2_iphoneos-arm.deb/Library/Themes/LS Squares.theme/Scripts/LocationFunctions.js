/****** LS Squares LOCATION functions *******/


var weatherLocCode = "";
var city = "";
var woeid;							/* 1 */

function updateCurrentLocation() 
{
	jQuery.get('file:///private/var/mobile/Documents/myLocation.txt', 
		function(appdata)
		{
			var myvar = appdata;
			var substr = appdata.split('\n');
			var tempLatitude = (substr[0]).split('=');
			var tempLongitude = (substr[1]).split('=');
			var latitude = $.trim(tempLatitude[1]);
			var longitude = $.trim(tempLongitude[1]);

			//get woeid from current latitude and longitude
			var locationURL = "http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20geo.placefinder%20where%20text%3D%22" + latitude + "%2C" + longitude + "%22%20and%20gflags%3D%22R%22&format=json";
			$.getJSON(locationURL, function(data) 
			{			
				var found = data.query.count;

				if (found > 0) 
				{
					woeid = data.query.results.Result.woeid;
					city = data.query.results.Result.city;
					
					var tempUnit;
					if (tempType == "C" || tempType == "c")			/* 6 */
						tempUnit = 'c';
					else
						tempUnit = 'f';

					//get old locale from woeid
					var weatherURL = "http://weather.yahooapis.com/forecastrss?w=" + woeid + "&u=" + tempUnit;
					$.get(weatherURL, function(data) 
					{
						var title = $(data).find('title').text();

						if (title != "Yahoo! Weather - ErrorCity not found") 
						{							
							weatherLocCode = $(data).find('guid').text().split('_')[0];									
							gpsBasedReading = true;
							fetchWeatherDataGPS(dealWithWeather, weatherLocCode);
						} 
						else 
						{
							if (xmldata == false)
							{
								gpsBasedReading = false;
								validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal);
								setInterval("fetchWeatherData(dealWithWeather, postal)", 1000*60*updateInterval);		/* 2 */
							} 
							else 
							{
								/* 4 */
							}
						}
					}).error(function() 
					{
						if (xmldata == false)
							dealWithWeather({error:true});
						else
						{
							//offline
						}
					});
				} 
				else 
				{
					if (xmldata == false) 
					{
						gpsBasedReading = false;
						validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal);
						setInterval("fetchWeatherData(dealWithWeather, postal)", 1000*60*updateInterval);		/* 2 */
					} 
					else 
					{
						//offline
					}
				}
			}).error(function()
			{
				if (xmldata == false)
					dealWithWeather({error:true});
				else
				{
					//offline
				}
			}); 
		}).error(function()
		{
			/* 5 */
			gpsBasedReading = false;
			validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal);
			setInterval("fetchWeatherData(dealWithWeather, postal)", 1000*60*updateInterval);		/* 2 */
		});
}


function fetchWeatherDataGPS(callback, weatherLocCode)		/* 7 */
{
	var tempUnit;

	if (tempType == "C" || tempType == "c") 		/* 6 */
		tempUnit = 'c'
	else
		tempUnit = 'f'

	var url = "http://xml.weather.yahoo.com/forecastrss/";
	var xml_request = new XMLHttpRequest();
	xml_request.onload = function(e) {xmlLoaded(e, xml_request, callback);}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url + weatherLocCode + '_' + tempUnit + '.xml');
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null); 

	return xml_request;
}


/************ FOOTNOTES/COMMENTS *************
1. "woeid" stands for "Where On Earth ID"
2. updateInterval and gpsCheckRefreshTimer variable is initialized and declared from Setup.js
3. updateInterval variable is initialized and declared from Setup.js
4. if there was a "cityText" element in the LS, assign it the "city" value based off Yahoo Geolocation XML instead Yahoo Weather XML, which surprisingly, are sometimes different from each other
5. myLocation.txt file wasn't found. stop GPS based readings. load weather readings based off the "locale" value instead
6. tempType variable is initialized and declared from Setup.js
7. different approach (url) is used compared to the initial one because of different input
*********************************************/