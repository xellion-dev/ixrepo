GPS Installation Instructions for 5.1.X & 6.X

First, you need to remove all traces of any previous installation of the MyLocation app.

1. Uninstall from Cydia
2. Go to /var/stash/Applications and make sure that MyLocation.app is NOT there. If it is, delete it.
3. Respring and then Reboot!
4. Create the folder /var/mobile/Documents if it doesn't exist
5. Open iFile. Go to /var/mobile and click on the blue arrow on the right side of Documents. Under "Ownership", make sure that "Owner" and "Group" are each set to "mobile". Under "Access Permissions" make sure that "Execute", "Write" and "Read" are checked for "User", "Group" and "World". Slide the "Apply hierarchically" to "On". Press "Done" and then respring.
6. Install the MyLocation app again using either my repo (see below) or from the Cydia-auto-install method (see below).
7. BEFORE opening the app, respring and then reboot!!!
8. Open the app and first allow it to use "Location Services" and turn "Sig. Change" to "On"
9. Close the MyLocation app and Enjoy!

iOS 6 NOTE
After installation, go into the Settings app -> Privacy -> Location Services
The MyLocation app should show up here and be turned on for you to get updates while traveling.
If it is not there, you must start back at step #1 and reinstall it until it is visable or it will only update by opening the app and allowing location services or a respring or reboot!

My Repo:
http://cydia.myrepospace.com/kohidevice/


BY: King_O_Hill (http://modmyi.com/members/3573381.html)
SOURCE: http://modmyi.com/forums/cydia-support/818501-mylocation-app-ios6x.html