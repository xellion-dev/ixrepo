Theming CCBB is fairly straightforward when you use the included themes as a template.

LightBox is the only aspect that needs explaining so here we go... 😕
This doesn't theme like normal icons...
It's hard to explain but icons react to the background of the page 'behind' Control Center.  This 'reaction' creates a negative coloring effect through the LightBox icon image.  Vibrant colors and Black will permit this 'negative colorizing' to show through.

• Our first suggestion is:
- DO NOT use BLACK anywhere in the icon; a weird effect occurs with this.  Use Dark Gray instead!
- Even with shadows, use Dark Gray.
- Vibrant RED will also cause this effect

• Blending colors can create the same weird effect at the location where the two colors meet.

• Let transparency be your friend!  We've noticed that decreasing the opacity (sometimes all the way down to 10%) will give optimal viewing results.  For colored icons, 20-30% transparency works pretty well.

• Background color from the Springboard and Apps can affect how the icon looks.
• The DISABLED state of the toggle will darken your icon.
• The ENABLED state of the toggle will brighten your icon.
- Take this into consideration as the 'brightness' is ridiculously BRIGHT!


*** You're going to need to do a lot of trial and error but eventually you should have something that pleases you. ***

Enjoy and thanx for your support!!!

Sincerely,
     vXBAKERXv & thazsar