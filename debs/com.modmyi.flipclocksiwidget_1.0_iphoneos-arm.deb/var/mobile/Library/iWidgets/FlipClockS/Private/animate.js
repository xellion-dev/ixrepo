<!-------------------------------------------------- Modded by Schnedi ------------------------------------------------>

// JavaScript Document

	//initial time
	var h_current = -1;
	var m1_current = -1;
	var m2_current = -1;
	
	function flip (upperId, lowerId, changeNumber, pathUpper, pathLower){
		var upperBackId = upperId+"Back";
		$(upperId).src = $(upperBackId).src;
		$(upperId).setStyle("height", "47px");
		$(upperId).setStyle("visibility", "visible");
		$(upperBackId).src = pathUpper+parseInt(changeNumber)+".png";
		
		$(lowerId).src = pathLower+parseInt(changeNumber)+".png";
		$(lowerId).setStyle("height", "0px");
		$(lowerId).setStyle("visibility", "visible");
		
		var flipUpper = new Fx.Tween(upperId, {duration: 200, transition: Fx.Transitions.Sine.easeInOut});
		flipUpper.addEvents({
			'complete': function(){
				var flipLower = new Fx.Tween(lowerId, {duration: 200, transition: Fx.Transitions.Sine.easeInOut});
					flipLower.addEvents({
						'complete': function(){	
							lowerBackId = lowerId+"Back";
							$(lowerBackId).src = $(lowerId).src;
							$(lowerId).setStyle("visibility", "hidden");
							$(upperId).setStyle("visibility", "hidden");
						}				});					
					flipLower.start('height',47);
					
			}
							});
		flipUpper.start('height',0);
		
		
	}//flip
				
	
	function retroClock(){
		
		// get new time
		 now = new Date();
		 h = now.getHours();
		 m1 = now.getMinutes() / 10;
		 m2 = now.getMinutes() % 10;
		 if(h < 12)
		 	ap = "AM";
		 else{ 
		 	if( h == 12 )
				ap = "PM";
			else{
				ap = "PM";
				h -= 12; }
		 }
		 
		 //change pads
		 
               if (Clock == "24h") {
		 if( h != h_current)
			flip('hoursUp', 'hoursDown', h, 'Single/24Up/'+ap+'/', 'Single/24Down/'+ap+'/');
			h_current = h;
              } else {
		 if( h != h_current)
			flip('hoursUp', 'hoursDown', h, 'Single/Up/'+ap+'/', 'Single/Down/'+ap+'/');
			h_current = h;
              }
		
		if( m2 != m2_current){
			flip('minutesUpRight', 'minutesDownRight', m2, 'Double/Up/Right/', 'Double/Down/Right/');
			m2_current = m2;
			
			flip('minutesUpLeft', 'minutesDownLeft', m1, 'Double/Up/Left/', 'Double/Down/Left/');
			m1_current = m1;
		}	
	}
	
	setInterval('retroClock()', 1000);