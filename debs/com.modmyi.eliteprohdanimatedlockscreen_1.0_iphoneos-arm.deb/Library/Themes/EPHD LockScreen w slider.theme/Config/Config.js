var twentyFourHourTime = false;
//Toggles twelve and twenty-four hour time.