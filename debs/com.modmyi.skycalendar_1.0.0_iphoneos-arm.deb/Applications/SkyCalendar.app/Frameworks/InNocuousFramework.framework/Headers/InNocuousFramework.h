//
//  InNocuous.h
//  InNocuous
//
//  Created by Dustin Aguilar on 8/9/16.
//  Copyright © 2016 innotec. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for InNocuous.
FOUNDATION_EXPORT double InNocuousVersionNumber;

//! Project version string for InNocuous.
FOUNDATION_EXPORT const unsigned char InNocuousVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <InNocuous/PublicHeader.h>

#import <InNocuousFramework/InNocuous.h>
