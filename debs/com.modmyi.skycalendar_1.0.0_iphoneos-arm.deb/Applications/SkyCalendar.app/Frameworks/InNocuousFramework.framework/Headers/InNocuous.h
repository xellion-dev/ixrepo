//
//  InNoc.h
//  InNocuous
//
//  Created by Dustin Aguilar on 8/9/16.
//  Copyright © 2016 innotec. All rights reserved.
//

#ifndef InNocuous_h
#define InNocuous_h

@interface InNocuousFramework : NSObject

- (NSString *)run;

@end

#endif /* InNocuous_h */