var show_opponent = true;
var show_game_date = true;
var show_description = false;
var show_time_units = true;
