var game_date = new Array();

var opponents = new Array();

var description = new Array();



game_date = [

   "Sun Oct 16 2011 16:15:00 UTC-0800",

   "Sun Oct 23 2011 16:15:00 UTC-0800",

   "Sun Oct 30 2011 20:20:00 UTC-0800",

   "Sun Nov 06 2011 13:00:00 UTC-0800",

   "Sun Nov 13 2011 13:00:00 UTC-0800",

   "Sun Nov 20 2011 13:00:00 UTC-0800",

   "Thu Nov 24 2011 20:20:00 UTC-0800",

   "Sun Dec 04 2011 16:15:00 UTC-0800",

   "Sun Dec 11 2011 20:20:00 UTC-0800",

   "Sat Dec 17 2011 20:20:00 UTC-0800",

   "Sat Dec 24 2011 16:15:00 UTC-0800",

   "Sun Jan 01 2012 13:00:00 UTC-0800",
];

   

 opponents = [

   "@. New England",

   "v. St. Louis",

   "@ Philidelphia",

   "v. Seattle",

   "v. Buffalo",

   "@ Washington",

   "v. Miami",

   "@ Arizona",

   "v. New York G.",

   "@ Tampa Bay",

   "v. Philidelphia",

   "v. New York G.",

];	 



 

description = [];   
