// initialize jQtouch
// icon and splash files are only when delivered as a 
// non-bundled package.

var jQT = new $.jQTouch({
    icon: 'images/icon.png',
    addGlossToIcon: true,
    startupScreen: 'images/splash.png',
    statusBar: 'black',
    formSelector: false
});


// evil global ref to localStorage.
var storage = window.localStorage;


$(document).ready(function(){
	
	
	// toDO : add phoneGap based connection check
	// and alert user if connection is not
	// available. For now, rely on jQueries ajax failure callback
	
	// load up the saved key/value pairs in localstorage.
	loadSettings();
	
	// character counter
	$('#msg').keyup(refreshCounter);


  // save the settings on slide-out of settings view
  // todo: why doesn't the button work?
	$('#settings').live('pageAnimationEnd',function(event,info){
		if(info.direction=='out'){
			saveSettings();		
		}
	});
	
	
});

//resets the character count in the message
function refreshCounter(){
  count=$('#msg').val().length;
  $('#counter').html(140-count);
}

function loadSettings(){
	$('#user').val(storage.getItem('user'));
	$('#pass').val(storage.getItem('pass'));
	$('#num').val(storage.getItem('num'));
	
	//console.log("loaded settings");//debug
}

function saveSettings(){
	storage.setItem('user',$('#user').val());
	storage.setItem('pass',$('#pass').val());
	storage.setItem('num',$('#num').val());

	
	//console.log("saved settings");//debug
}


function setStatus(theStatus,type){
	//type is OK,ERR,PROC
	
	$('#status').html(theStatus);
	
	if(type=="OK"){
		$('#status').attr('class','noerror');
	}
	
	if(type=="ERR"){
		$('#status').attr('class','haserror');

	}
	
	if(type=="NOTIF"){
		$('#status').attr('class','notif');

	}
	
	//todo: implement a better system to display these.
	//including a fadeout, and a spinning wheel
	$('#status').fadeIn('slow');

}

//handler for the clear button
function clearmsg(){
  $('#msg').val("");
  refreshCounter();
}


//magic happens here ----------------------------------

function sendsms(){

	user=$('#user').val();
	passwd=$('#pass').val();
	num=$('#num').val();
	msg=$('#msg').val();

	dataString={'user': user, 'pass':passwd, 'num':num, 'msg':msg}
	
	saveSettings(); //save the last number you were trying to send to
	setStatus("Sending...please wait", "NOTIF");
	
    $.ajax({
        type:"GET",
        url:"http://www.cultofgenesis.com/websms/websms.php",
        timeout:30000, //allowing a 20second timeout here. login/blah blah and everything.
        data: dataString,
        dataType:"json",
        //callback for successful requets
        success: function(data) {
            if(data.status == "OK") {
            // Things probably went well. So set it to OK and clear the msg field, TODO: clear and set focus
                setStatus("Message Sent. " + data.count + " Left","OK");
            } else {
                //alert(data); //debug
                setStatus(data.status,"ERR");
            }
        },
       error: function(x,t,m){
            //set status on timeout.
            if(t==="timeout"){
                setStatus("Request Timed out","ERR");
            } else {
                setStatus("errored here","ERR");
            }
       } 
            
    });

}


