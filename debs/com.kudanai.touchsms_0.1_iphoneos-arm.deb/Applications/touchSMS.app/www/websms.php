<?php
/*....
PHP script to act as a go-between for Dhiraagu websms
to minimize data-exchange. Ideally for use over a 
mobile network.


just upload the php file to some place that supports 
php_curl and make a standard GET request to the file
with the follwing parameters:

user,pass,num,msg,<cookie>

where cookie is optional, and is the session string of 
an existing session.

The Script returns a JSON encoded status message.
*/

$old_error_handler = set_error_handler("myErrorHandler");
$SessionData=array(
	'status' => 'OK',
	'count' => NULL,
	'cookie' => NULL,
	'retries' => 0,
);

function terminate_now() {
	global $SessionData;
	echo json_encode($SessionData)."\n";
	exit(1);
}

function myErrorHandler($errno, $errstr, $errfile, $errline)
{
 	
    global $SessionData;
    if (!(error_reporting() & $errno)) {
        return;
    }

    switch ($errno) {
    case E_USER_ERROR:
        $SessionData['status']="ERR: ".$errstr;
        terminate_now();
        break;

    case E_USER_WARNING:
        $SessionData['status']="WARN: ".$errstr;
        break;

    default:
        $SessionData['status']="ERRUNKWN: ".$errstr;
	terminate_now();
        break;
    }

    return true;
}


function make_curl_request($url,$post_params,$useCookie) {
	
	global $SessionData;

 	$ch = curl_init($url);
 	curl_setopt($ch, CURLOPT_HEADER, 0);
  curl_setopt($ch,CURLOPT_AUTOREFERER,1);
  curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
  curl_setopt($ch,CURLOPT_HEADER,1);
	curl_setopt($ch, CURLOPT_POST, 2);
	curl_setopt($ch, CURLOPT_POSTFIELDS,$post_params);
  curl_setopt($ch,CURLOPT_COOKIESESSION,1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  if($useCookie) {
		curl_setopt($ch,CURLOPT_COOKIE,'Dhi='.$SessionData['cookie']);
	}

  $output = curl_exec($ch);
  curl_close($ch);

	return $output;
}

function login()
{
	global $SessionData;
	$username=$_GET['user'];
	$password=$_GET['pass'];

	$return=make_curl_request('http://websms.dhimobile.com.mv/cgi-bin/websms/index.pl',
				'username='.urlencode($username).'&password='.urlencode($password),FALSE);

	if(preg_match('/^Set-Cookie: Dhi=(.*?);/m', $return, $cookie_out)) {
		$SessionData['cookie']=$cookie_out[1];

		//CHECK DAILY QUOTA
		if(preg_match('/send (.*?) more/',$return,$msg_count)) {
			if(($SessionData['count']=$msg_count[1])<1){
				trigger_error('You have Reached your Daily Quota',E_USER_ERROR);
				
			} else {
				sendsms();
			}
		} 
		return true;

	} else {
		trigger_error('Invalid Username and/or Password',E_USER_ERROR);
		return false;
	}
}

function sendsms() {

	global $SessionData;
	$number=$_GET['num'];
	$message=$_GET['msg'];

	if(strlen($message) > 140) {
		trigger_error('Message Truncated',E_USER_WARNING);
		$message=substr($message,0,140);
	}

        $return=make_curl_request('http://websms.dhimobile.com.mv/cgi-bin/websms/send_message.pl',
				'mobilenumber='.urlencode($number).'&message='.urlencode($message),TRUE);

	//VALIDATE THE RETURN STUFF
	if(preg_match('/send (.*?) more/',$return,$msg_count)) {
		$SessionData['count']=$msg_count[1];
	} else {
		if(($SessionData['retries']++)>3){
			trigger_error('maximum number of retries exceeded',E_USER_ERROR);
		}
		login();
	}

}


/////////////BEGIN HERE///////all hail the ugliness//////////////////////////////////////////////////

if (isset($_GET['user']) && isset($_GET['pass']) && isset($_GET['msg']) && isset($_GET['num'])) {
	
	//then validate the number///
	if(preg_match("/^7[4-9][0-9]{5}$/",$_GET['num'],$number)){
		$_GET['num']=$number[0];
	} else {
		trigger_error('Invalid Number Format',E_USER_ERROR);
	}
} else {
	trigger_error('Insufficiant Arguments',E_USER_ERROR);
}

if(isset($_GET['cookie'])){
	$SessionData['cookie']=$_GET['cookie'];
	sendsms();
} else {
	login();
}


terminate_now();
?>

