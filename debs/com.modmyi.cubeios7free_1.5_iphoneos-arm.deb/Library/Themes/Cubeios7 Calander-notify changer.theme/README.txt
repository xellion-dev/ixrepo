****Open file above "Info.plist" and change the follow below to edit notification colors!



<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>


	<key>BadgeStyle</key>
	<string>
		position:absolute;
		color: #000000;     <-Change notification count color
		border-radius: 50%;
		font-size:12px;
		text-align:center;
		width:15px;
		height:15px;
		margin-top:0px; 
		margin-left:0px;
		background-color:#5902fb;  <-Change notification background color
		opacity:1.0;
</string>
<key>CalendarIconDateStyle</key>
<string> 
line-height: 1em;
margin-top:20px;
color: white;
font-size: 14px;
</string>


 <key>CalendarIconDayStyle</key>
 <string>color:#060000; font-size: 6px; 
 padding: 10px 0 0 0;
 text-shadow: 0px 1px 0px #fffefe</string>

	<key>UndockedIconLabelStyle</key>
	<string>

		font-size:12px;
		margin-top:-2px;
		letter-spacing: 0px;
	
	font-family: Helvetica;
	font-weight: 400;
	color: #2b2e32;
	opacity: 1.0;
	text-shadow: 0px 1px 0px #474849, 0px -1px 0 #1a1a1a;
	</string>
		<key>DockedIconLabelStyle</key>
	<string>

		font-size:12px;
		margin-top:-2px;
		letter-spacing: 0px;
	
	font-family: Helvetica;
	font-weight: 400;
	color: #2b2e32;
	opacity: 0;
	text-shadow: 0px 1px 0px #474849, 0px -1px 0 #1a1a1a;
	</string>


</dict>
</plist>


